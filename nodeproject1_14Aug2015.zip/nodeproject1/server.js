var express = require('express');
var bodyParser = require('body-parser');
var morgan = require('morgan');
var config = require('./config');
var mongodb = require('./Dao/db');
var app = module.exports = express();
var cons = require('consolidate');

mongodb.init(config.database, function(){
    // Use to get static public resources such as js and images
    app.use('/admin', express.static(__dirname + '/views/'));

    app.use(bodyParser.urlencoded({extended: true}));
    app.use(bodyParser.json());
    app.use(bodyParser.raw());
    app.use(morgan('dev'));

// assign the swig engine to .html files
    app.engine('html', cons.swig);
// set .html as the default extension
    app.set('view engine', 'html');
    app.set('views', __dirname + '/views');


    app.get('/home',function(req, res){
        res.sendFile(__dirname + '/public/views/index.html');
    });
    require('./controllers');
    app.listen(config.port,function(er){
        if(er){
            console.log(er);
        }
        else{
            console.log('Listening To Port '+config.port);
        }
    });

});