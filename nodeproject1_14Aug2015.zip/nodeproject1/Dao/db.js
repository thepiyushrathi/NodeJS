var MongoClient = require('mongodb').MongoClient;
var config = require('../config');

var host = config.host;
var port = config.mongodbPort;
var db;

exports.getdb = function(){
    return db;
};

exports.init = function(appdb, callback){
    MongoClient.connect("mongodb://localhost:"+port+"/"+config.database, function(err, database){
        db = database;
        console.log("connected to the database "+config.database);
        if(err){
            throw err;
        }
        callback();
    });
}