var model = require("./model");

GENDER = {
    MALE : 1,
    FEMALE : 2,
    SECRET : 3,
    validate : function(val){
        if(val!=1 && val!=2 && val!=3){
            throw new model.AppException("gender001", "Invalid gender");
        }
    }
};

USER_STATE = {
    ACTIVE : 1,
    INACTIVE : 2,
    validate : function(val){
        if(val!=1 && val!=2){
            throw new model.AppException("state001", "Invalid state code");
        }
    }
};

PLATFORM = {
    IOS : 1,
    ANDROID : 2,
    validate : function(val){
        if(val!=1 && val!=2){
            throw new model.AppException("platform001", "Invalid platform code");
        }
    }
};

/**
 * @param fName : first name admin user
 * @param lName : last name of admin user
 * @param email : email address of admin user
 * @param status : status if is active or not
 * @param password : password to login to the account
 * @param pin : Optional to use pin to login
 * @param cDate : date of creation of admin user account
 * @param uDate : date of last update in admin user account
 */
function adminUser(fName, lName, email, phoneNum, status, password, pin, cDate, uDate){
    USER_STATE.validate(status);
    this.fName = fName;
    this.lName = lName;
    this.email = email;
    this.phoneNum = phoneNum;
    this.status = status;
    this.password = password;
    this.pin = pin;
    this.cDate = cDate;
    this.uDate = uDate;
    removeNullKeys(this);
};

/**
 * @param name : name of user
 * @param email : email id of user
 * @param address : address of user
 * @param pNum : phone number
 * @param weight : weight of user
 * @param height : height of user
 * @param gender : gender of user
 * @param status : status if active or not
 * @param cDate : date of creation of user account
 * @param uDate : date of last update in user account
 */
function User(name, email, address, pNum, weight, height, gender, status, cDate, uDate){
    USER_STATE.validate(status);
    this.name = name;
    this.email = email;
    this.address = address;
    this.pNum = pNum;
    this.weight = weight;
    this.height = height;
    this.gender = gender;
    this.status = status;
    this.cDate = cDate;
    this.uDate = uDate;
    removeNullKeys(this);
};


module.exports = {
    GENDER : GENDER,
    USER_STATE : USER_STATE,
    User : User,
    adminUser : adminUser,
    PLATFORM : PLATFORM
};

function removeNullKeys(ob){
    for(var i in ob){
        if(ob[i]==null){
            delete ob[i];
        }
    }
};