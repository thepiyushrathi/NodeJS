module.exports = {
    "database" : "travelmate",
    "mongodbPort" : 27017,
    "port" : process.env.PORT || 3000,
    "host" : "127.0.0.1",
    "secretKey" : "MySecretKey"
}