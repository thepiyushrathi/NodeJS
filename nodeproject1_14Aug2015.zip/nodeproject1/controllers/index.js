module.exports  = {
    adminUserController : require('./adminUserController')

}