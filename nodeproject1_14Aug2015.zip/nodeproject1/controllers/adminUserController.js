var config = require('../config');
var mongodb = require('../Dao/db');
var app = require('../server');


app.get("/admin/login", function(req, res) {
    res.render("login.html", {
        title : "login"
    });
});
app.post('/register/user', function(req, res){
    if(req.body.uname != null && req.body.uemail != null && req.body.upass != null) {
        var user = {};
        user.name = req.body.uname;
        user.email = req.body.uemail;
        user.pass = req.body.upass;

        mongodb.getdb().collection("admin_user", function(error,collection){
            console.log("we have the collection admin_user");
            collection.insert({
                user_name: user.name,
                email: user.email,
                password: user.pass
            }, function(){
                console.log("successfully inserted user");
            });
        });

        res.json({success: 1, message: 'User registered', username: user.name, email: user.email});
    }
    else
    {
        res.json({success: 0, message: 'Error'});
    }
    res.end;
});